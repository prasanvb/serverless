
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanvb',
  applicationName: 'serverless',
  appUid: '6K9wR4VH3N8mjMd5Hn',
  orgUid: '88a64848-263a-4c75-8895-8b723ba902a9',
  deploymentUid: '6825e2cf-f53e-49bc-befa-66ee15278877',
  serviceName: 'serverless-env-var',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-env-var-dev-createUser', timeout: 30 };

try {
  const userHandler = require('./functions/user/user.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}