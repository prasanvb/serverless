
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanvb',
  applicationName: 'serverless',
  appUid: '6K9wR4VH3N8mjMd5Hn',
  orgUid: '88a64848-263a-4c75-8895-8b723ba902a9',
  deploymentUid: '80560aa7-a9e7-41a9-9072-80130075bcb8',
  serviceName: 'serverless-dynamodb',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-dynamodb-dev-createUser', timeout: 30 };

try {
  const userHandler = require('./functions/user/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}